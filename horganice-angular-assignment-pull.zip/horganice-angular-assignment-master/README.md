### This is an Angular 1 skill test

1. you can run this with some simple script that you prefer such as `php -S localhost:8080 -t .` or node http-server.
2. fork this project to your repo.
3. create new branch.
4. edit code to what we need (follow email instruction).
5. add some HIPPY style to persude us to hire you ;)
6. if you finish this assignment please pull request to my repo.

### hint
1. you should commit your code continuously
2. we love creative guys
